from fastapi import FastAPI
from pydantic import BaseModel
from typing import List, Dict, Any

from services.finance_ai import analyze_finances

app = FastAPI(
    title="AI Finance Controller AI Service",
    version="1.0.0"
)


class FinanceRequest(BaseModel):
    transactions: List[Dict[str, Any]]


@app.get("/")
def root():
    return {
        "message": "AI Finance Controller AI Service is running!"
    }


@app.post("/analyze")
def analyze(request: FinanceRequest):
    insights = analyze_finances(
        request.transactions
    )

    return {
        "insights": insights
    }