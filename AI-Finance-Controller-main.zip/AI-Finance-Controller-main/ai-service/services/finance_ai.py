from datetime import datetime


def analyze_finances(transactions):

    insights = []

    if not transactions:
        return [
            "Add some transactions so the AI can analyze your financial behavior."
        ]

    income = 0
    expenses = 0

    categories = {}

    monthly_expenses = {}

    for transaction in transactions:

        amount = float(
            transaction.get("amount", 0)
        )

        transaction_type = transaction.get(
            "type", ""
        )

        category = transaction.get(
            "category", "Other"
        )

        date_string = transaction.get(
            "date"
        )

        # -------------------------------
        # INCOME
        # -------------------------------

        if transaction_type == "income":

            income += amount

        # -------------------------------
        # EXPENSE
        # -------------------------------

        elif transaction_type == "expense":

            expenses += amount

            categories[category] = (
                categories.get(category, 0)
                + amount
            )

            # Monthly expense calculation
            if date_string:

                try:

                    date = datetime.fromisoformat(
                        date_string.replace(
                            "Z",
                            "+00:00"
                        )
                    )

                    month_key = date.strftime(
                        "%Y-%m"
                    )

                    monthly_expenses[
                        month_key
                    ] = (
                        monthly_expenses.get(
                            month_key,
                            0
                        )
                        + amount
                    )

                except Exception:
                    pass


    # ==========================================
    # BALANCE
    # ==========================================

    balance = income - expenses


    # ==========================================
    # SAVINGS RATE
    # ==========================================

    if income > 0:

        savings_rate = (
            balance / income
        ) * 100

        if savings_rate < 10:

            insights.append(
                "Your savings rate is low. "
                "Consider reducing unnecessary expenses."
            )

        elif savings_rate >= 30:

            insights.append(
                "Excellent savings rate. "
                "You are maintaining strong financial discipline."
            )

        else:

            insights.append(
                "Your savings rate is moderate. "
                "Try to increase your monthly savings gradually."
            )


    # ==========================================
    # OVERSPENDING
    # ==========================================

    if expenses > income and income > 0:

        insights.append(
            "Warning: Your expenses are higher "
            "than your income."
        )


    # ==========================================
    # HIGHEST SPENDING CATEGORY
    # ==========================================

    if categories:

        highest_category = max(
            categories,
            key=categories.get
        )

        highest_amount = categories[
            highest_category
        ]

        insights.append(
            f"Your highest spending category is "
            f"{highest_category} with ₹"
            f"{highest_amount:.0f}."
        )

        if income > 0:

            category_percentage = (
                highest_amount / income
            ) * 100

            if category_percentage > 30:

                insights.append(
                    f"{highest_category} consumes a "
                    f"large portion of your income. "
                    f"Consider setting a budget for this category."
                )


    # ==========================================
    # NEXT MONTH EXPENSE PREDICTION
    # ==========================================

    if monthly_expenses:

        average_monthly_expense = (
            sum(monthly_expenses.values())
            / len(monthly_expenses)
        )

        predicted_expense = (
            average_monthly_expense
        )

        insights.append(
            f"🤖 AI prediction: Your estimated "
            f"next-month expense is approximately "
            f"₹{predicted_expense:.0f}, based on "
            f"your historical spending."
        )


    # ==========================================
    # FINANCIAL RECOMMENDATION
    # ==========================================

    if expenses > 0:

        insights.append(
            "AI recommendation: Review your "
            "recurring expenses and identify at "
            "least one expense you can reduce this month."
        )


    return insights