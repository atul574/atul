const express = require("express");
const Transaction = require("../models/Transaction");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();


// ==========================================
// ADD TRANSACTION
// ==========================================

router.post(
  "/",
  authMiddleware,
  async (req, res) => {
    try {
      const {
        type,
        amount,
        category,
        description,
        date,
        paymentMethod,
      } = req.body;

      if (!type || !amount || !category) {
        return res.status(400).json({
          message:
            "Type, amount and category are required",
        });
      }

      const transaction =
        await Transaction.create({
          user: req.userId,
          type,
          amount,
          category,
          description,
          date: date || new Date(),
          paymentMethod,
        });

      res.status(201).json({
        message:
          "Transaction added successfully",
        transaction,
      });

    } catch (error) {
      console.error("Add transaction error:", error);

      res.status(500).json({
        message: "Server error",
      });
    }
  }
);


// ==========================================
// GET USER TRANSACTIONS
// ==========================================

router.get(
  "/:userId",
  authMiddleware,
  async (req, res) => {
    try {

      if (req.userId !== req.params.userId) {
        return res.status(403).json({
          message: "Access denied",
        });
      }

      const transactions =
        await Transaction.find({
          user: req.userId,
        }).sort({
          date: -1,
        });

      res.json(transactions);

    } catch (error) {
      console.error(
        "Get transactions error:",
        error
      );

      res.status(500).json({
        message: "Server error",
      });
    }
  }
);


// ==========================================
// UPDATE TRANSACTION
// ==========================================

router.put(
  "/:id",
  authMiddleware,
  async (req, res) => {
    try {

      const transaction =
        await Transaction.findOneAndUpdate(
          {
            _id: req.params.id,
            user: req.userId,
          },
          req.body,
          {
            new: true,
            runValidators: true,
          }
        );

      if (!transaction) {
        return res.status(404).json({
          message: "Transaction not found",
        });
      }

      res.json({
        message:
          "Transaction updated successfully",
        transaction,
      });

    } catch (error) {
      console.error(
        "Update transaction error:",
        error
      );

      res.status(500).json({
        message: "Server error",
      });
    }
  }
);


// ==========================================
// DELETE TRANSACTION
// ==========================================

router.delete(
  "/:id",
  authMiddleware,
  async (req, res) => {
    try {

      const transaction =
        await Transaction.findOneAndDelete({
          _id: req.params.id,
          user: req.userId,
        });

      if (!transaction) {
        return res.status(404).json({
          message: "Transaction not found",
        });
      }

      res.json({
        message:
          "Transaction deleted successfully",
      });

    } catch (error) {
      console.error(
        "Delete transaction error:",
        error
      );

      res.status(500).json({
        message: "Server error",
      });
    }
  }
);


module.exports = router;