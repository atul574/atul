const express = require("express");
const Budget = require("../models/Budget");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();


// ==========================================
// CREATE BUDGET
// ==========================================

router.post(
  "/",
  authMiddleware,
  async (req, res) => {
    try {
      const {
        category,
        amount,
        month,
      } = req.body;

      if (!category || !amount || !month) {
        return res.status(400).json({
          message: "All fields are required",
        });
      }

      const budget = await Budget.create({
        user: req.userId,
        category,
        amount: Number(amount),
        month,
      });

      res.status(201).json({
        message: "Budget created successfully",
        budget,
      });

    } catch (error) {
      console.error(
        "Create budget error:",
        error
      );

      res.status(500).json({
        message: "Server error",
      });
    }
  }
);


// ==========================================
// GET USER BUDGETS
// ==========================================

router.get(
  "/:userId",
  authMiddleware,
  async (req, res) => {
    try {

      if (req.userId !== req.params.userId) {
        return res.status(403).json({
          message: "Access denied",
        });
      }

      const budgets = await Budget.find({
        user: req.userId,
      }).sort({
        createdAt: -1,
      });

      res.json(budgets);

    } catch (error) {
      console.error(
        "Get budgets error:",
        error
      );

      res.status(500).json({
        message: "Server error",
      });
    }
  }
);


// ==========================================
// DELETE BUDGET
// ==========================================

router.delete(
  "/:id",
  authMiddleware,
  async (req, res) => {
    try {

      const budget =
        await Budget.findOneAndDelete({
          _id: req.params.id,
          user: req.userId,
        });

      if (!budget) {
        return res.status(404).json({
          message: "Budget not found",
        });
      }

      res.json({
        message: "Budget deleted successfully",
      });

    } catch (error) {
      console.error(
        "Delete budget error:",
        error
      );

      res.status(500).json({
        message: "Server error",
      });
    }
  }
);


module.exports = router;