const express = require("express");
const authMiddleware = require("../middleware/authMiddleware");

const router = express.Router();

router.post(
  "/insights",
  authMiddleware,
  async (req, res) => {
    try {
      const response = await fetch(
        "http://127.0.0.1:8000/analyze",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            transactions:
              req.body.transactions || [],
          }),
        }
      );

      if (!response.ok) {
        throw new Error(
          "AI service returned an error"
        );
      }

      const data = await response.json();

      res.json(data);
    } catch (error) {
      console.error("AI service error:", error);

      res.status(500).json({
        message:
          "AI service is currently unavailable",
      });
    }
  }
);

module.exports = router;