function SummaryCards({ transactions }) {
  const income = transactions
    .filter((item) => item.type === "income")
    .reduce((total, item) => total + Number(item.amount), 0);

  const expense = transactions
    .filter((item) => item.type === "expense")
    .reduce((total, item) => total + Number(item.amount), 0);

  const balance = income - expense;

  const savingsRate =
    income > 0
      ? ((balance / income) * 100).toFixed(1)
      : 0;

  return (
    <div className="summary-grid">
      <div className="summary-card">
        <h3>Total Income</h3>
        <div className="amount income">
          ₹{income.toLocaleString()}
        </div>
      </div>

      <div className="summary-card">
        <h3>Total Expenses</h3>
        <div className="amount expense">
          ₹{expense.toLocaleString()}
        </div>
      </div>

      <div className="summary-card">
        <h3>Balance</h3>
        <div className="amount">
          ₹{balance.toLocaleString()}
        </div>
      </div>

      <div className="summary-card">
        <h3>Savings Rate</h3>
        <div className="amount">
          {savingsRate}%
        </div>
      </div>
    </div>
  );
}

export default SummaryCards;