import { useState } from "react";
import { apiRequest } from "../services/api";

function BudgetForm({ onBudgetCreated }) {
  const [form, setForm] = useState({
    category: "Food",
    amount: "",
    month: new Date().toISOString().substring(0, 7),
  });

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const data = await apiRequest("/budgets", {
        method: "POST",
        body: JSON.stringify({
          category: form.category,
          amount: Number(form.amount),
          month: form.month,
        }),
      });

      onBudgetCreated(data.budget);

      alert("Budget created successfully!");

      setForm({
        ...form,
        amount: "",
      });
    } catch (error) {
      alert(error.message);
    }
  };

  return (
    <div className="card">
      <h2>Create Budget</h2>

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Category</label>

          <select
            name="category"
            value={form.category}
            onChange={handleChange}
          >
            <option>Food</option>
            <option>Shopping</option>
            <option>Transport</option>
            <option>Bills</option>
            <option>Entertainment</option>
            <option>Healthcare</option>
            <option>Education</option>
            <option>Other</option>
          </select>
        </div>

        <div className="form-group">
          <label>Budget Amount</label>

          <input
            type="number"
            name="amount"
            value={form.amount}
            onChange={handleChange}
            min="1"
            placeholder="Example: 5000"
            required
          />
        </div>

        <div className="form-group">
          <label>Month</label>

          <input
            type="month"
            name="month"
            value={form.month}
            onChange={handleChange}
            required
          />
        </div>

        <button className="primary-btn">
          Create Budget
        </button>
      </form>
    </div>
  );
}

export default BudgetForm;