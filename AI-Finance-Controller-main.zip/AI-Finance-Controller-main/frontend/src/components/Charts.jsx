import {
  PieChart,
  Pie,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  BarChart,
  Bar,
} from "recharts";

function Charts({ transactions }) {

  // ==========================================
  // EXPENSES BY CATEGORY
  // ==========================================

  const categories = {};

  transactions
    .filter((item) => item.type === "expense")
    .forEach((item) => {

      categories[item.category] =
        (categories[item.category] || 0) +
        Number(item.amount);

    });

  const categoryData =
    Object.entries(categories).map(
      ([name, value]) => ({
        name,
        value,
      })
    );


  // ==========================================
  // MONTHLY ANALYTICS
  // ==========================================

  const monthly = {};

  transactions.forEach((item) => {

    const date = new Date(item.date);

    const month =
      date.toLocaleDateString(
        "en-IN",
        {
          month: "short",
          year: "numeric",
        }
      );

    if (!monthly[month]) {

      monthly[month] = {
        month,
        income: 0,
        expense: 0,
        savings: 0,
      };

    }

    if (item.type === "income") {

      monthly[month].income +=
        Number(item.amount);

    }

    if (item.type === "expense") {

      monthly[month].expense +=
        Number(item.amount);

    }

  });


  // Calculate savings

  Object.values(monthly).forEach(
    (item) => {

      item.savings =
        item.income - item.expense;

    }
  );


  const monthlyData =
    Object.values(monthly);


  return (

    <>

      {/* ======================================
          CHART 1 + CHART 2
      ====================================== */}

      <div className="dashboard-grid">


        {/* EXPENSE CATEGORY */}

        <div className="card">

          <h2>
            Expenses by Category
          </h2>

          {categoryData.length === 0 ? (

            <p>
              No expense data available.
            </p>

          ) : (

            <ResponsiveContainer
              width="100%"
              height={300}
            >

              <PieChart>

                <Pie
                  data={categoryData}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  label
                />

                <Tooltip />

                <Legend />

              </PieChart>

            </ResponsiveContainer>

          )}

        </div>


        {/* INCOME VS EXPENSE */}

        <div className="card">

          <h2>
            Income vs Expenses
          </h2>

          {monthlyData.length === 0 ? (

            <p>
              No monthly data available.
            </p>

          ) : (

            <ResponsiveContainer
              width="100%"
              height={300}
            >

              <LineChart
                data={monthlyData}
              >

                <CartesianGrid
                  strokeDasharray="3 3"
                />

                <XAxis
                  dataKey="month"
                />

                <YAxis />

                <Tooltip />

                <Legend />

                <Line
                  type="monotone"
                  dataKey="income"
                  stroke="#16a34a"
                  strokeWidth={3}
                />

                <Line
                  type="monotone"
                  dataKey="expense"
                  stroke="#dc2626"
                  strokeWidth={3}
                />

              </LineChart>

            </ResponsiveContainer>

          )}

        </div>

      </div>


      {/* ======================================
          MONTHLY SAVINGS
      ====================================== */}

      <div
        className="card"
        style={{
          marginTop: "22px",
        }}
      >

        <h2>
          📊 Monthly Savings Analysis
        </h2>

        {monthlyData.length === 0 ? (

          <p>
            Add transactions to see your
            monthly savings analysis.
          </p>

        ) : (

          <ResponsiveContainer
            width="100%"
            height={320}
          >

            <BarChart
              data={monthlyData}
            >

              <CartesianGrid
                strokeDasharray="3 3"
              />

              <XAxis
                dataKey="month"
              />

              <YAxis />

              <Tooltip />

              <Legend />

              <Bar
                dataKey="income"
                name="Income"
              />

              <Bar
                dataKey="expense"
                name="Expenses"
              />

              <Bar
                dataKey="savings"
                name="Savings"
              />

            </BarChart>

          </ResponsiveContainer>

        )}

      </div>

    </>

  );

}

export default Charts;