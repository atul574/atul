import { useEffect, useState } from "react";

function TransactionForm({
  onSubmit,
  editingTransaction,
  onCancelEdit,
}) {
  const [form, setForm] = useState({
    type: "expense",
    amount: "",
    category: "Food",
    description: "",
    paymentMethod: "upi",
    date: "",
  });

  useEffect(() => {
    if (editingTransaction) {
      setForm({
        type: editingTransaction.type,
        amount: editingTransaction.amount,
        category: editingTransaction.category,
        description: editingTransaction.description || "",
        paymentMethod: editingTransaction.paymentMethod,
        date: editingTransaction.date
          ? editingTransaction.date.substring(0, 10)
          : "",
      });
    }
  }, [editingTransaction]);

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    await onSubmit({
      ...form,
      amount: Number(form.amount),
    });

    if (!editingTransaction) {
      setForm({
        type: "expense",
        amount: "",
        category: "Food",
        description: "",
        paymentMethod: "upi",
        date: "",
      });
    }
  };

  return (
    <div className="card">
      <h2>
        {editingTransaction
          ? "Edit Transaction"
          : "Add Transaction"}
      </h2>

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Type</label>

          <select
            name="type"
            value={form.type}
            onChange={handleChange}
          >
            <option value="expense">Expense</option>
            <option value="income">Income</option>
          </select>
        </div>

        <div className="form-group">
          <label>Amount</label>

          <input
            type="number"
            name="amount"
            value={form.amount}
            onChange={handleChange}
            min="1"
            required
          />
        </div>

        <div className="form-group">
          <label>Category</label>

          <select
            name="category"
            value={form.category}
            onChange={handleChange}
          >
            <option>Food</option>
            <option>Shopping</option>
            <option>Transport</option>
            <option>Bills</option>
            <option>Entertainment</option>
            <option>Salary</option>
            <option>Healthcare</option>
            <option>Education</option>
            <option>Other</option>
          </select>
        </div>

        <div className="form-group">
          <label>Description</label>

          <input
            type="text"
            name="description"
            value={form.description}
            onChange={handleChange}
            placeholder="Example: Grocery shopping"
          />
        </div>

        <div className="form-group">
          <label>Payment Method</label>

          <select
            name="paymentMethod"
            value={form.paymentMethod}
            onChange={handleChange}
          >
            <option value="upi">UPI</option>
            <option value="cash">Cash</option>
            <option value="card">Card</option>
            <option value="bank">Bank</option>
            <option value="other">Other</option>
          </select>
        </div>

        <div className="form-group">
          <label>Date</label>

          <input
            type="date"
            name="date"
            value={form.date}
            onChange={handleChange}
          />
        </div>

        <button className="primary-btn">
          {editingTransaction
            ? "Update Transaction"
            : "Add Transaction"}
        </button>

        {editingTransaction && (
          <button
            type="button"
            className="secondary-btn"
            style={{
              width: "100%",
              marginTop: "10px",
            }}
            onClick={onCancelEdit}
          >
            Cancel
          </button>
        )}
      </form>
    </div>
  );
}

export default TransactionForm;