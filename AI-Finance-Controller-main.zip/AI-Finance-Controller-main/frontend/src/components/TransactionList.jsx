import { useState } from "react";

function TransactionList({
  transactions,
  onDelete,
  onEdit,
}) {
  const [search, setSearch] = useState("");
  const [type, setType] = useState("all");

  const filtered = transactions.filter((item) => {
    const searchText =
      `${item.category} ${item.description || ""}`.toLowerCase();

    const matchesSearch = searchText.includes(
      search.toLowerCase()
    );

    const matchesType =
      type === "all" || item.type === type;

    return matchesSearch && matchesType;
  });

  return (
    <div className="card">
      <h2>Transaction History</h2>

      <div className="filter-row">
        <input
          placeholder="Search transactions..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <select
          value={type}
          onChange={(e) => setType(e.target.value)}
        >
          <option value="all">All</option>
          <option value="income">Income</option>
          <option value="expense">Expense</option>
        </select>
      </div>

      {filtered.length === 0 ? (
        <p>No transactions found.</p>
      ) : (
        filtered.map((item) => (
          <div
            className="transaction-item"
            key={item._id}
          >
            <div className="transaction-top">
              <strong>
                {item.category}
              </strong>

              <strong
                className={
                  item.type === "income"
                    ? "income"
                    : "expense"
                }
              >
                {item.type === "income" ? "+" : "-"}₹
                {Number(item.amount).toLocaleString()}
              </strong>
            </div>

            <p>
              {item.description || "No description"}
            </p>

            <small>
              {item.paymentMethod.toUpperCase()} •{" "}
              {new Date(item.date).toLocaleDateString()}
            </small>

            <div className="action-buttons">
              <button
                className="edit-btn"
                onClick={() => onEdit(item)}
              >
                Edit
              </button>

              <button
                className="delete-btn"
                onClick={() => onDelete(item._id)}
              >
                Delete
              </button>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

export default TransactionList;