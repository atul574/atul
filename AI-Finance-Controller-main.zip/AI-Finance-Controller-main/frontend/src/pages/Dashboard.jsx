import { useEffect, useState } from "react";

import Navbar from "../components/Navbar";
import SummaryCards from "../components/SummaryCards";
import TransactionForm from "../components/TransactionForm";
import TransactionList from "../components/TransactionList";
import Charts from "../components/Charts";
import BudgetForm from "../components/BudgetForm";

import { apiRequest } from "../services/api";

function Dashboard() {
  const [transactions, setTransactions] = useState([]);
  const [editingTransaction, setEditingTransaction] =
    useState(null);

  const [budgets, setBudgets] = useState([]);

  const [aiInsights, setAiInsights] = useState([]);

  const user = JSON.parse(
    localStorage.getItem("user")
  );

  // ==========================================
  // FINANCIAL HEALTH SCORE
  // ==========================================

  const calculateHealthScore = () => {
    const income = transactions
      .filter((item) => item.type === "income")
      .reduce(
        (sum, item) =>
          sum + Number(item.amount),
        0
      );

    const expenses = transactions
      .filter((item) => item.type === "expense")
      .reduce(
        (sum, item) =>
          sum + Number(item.amount),
        0
      );

    // No income means score cannot be calculated
    if (income === 0) {
      return 0;
    }

    // Savings rate
    const savingsRate =
      ((income - expenses) / income) * 100;

    // Start with a neutral score
    let score = 50;

    // ------------------------------------------
    // SAVINGS PERFORMANCE
    // ------------------------------------------

    if (savingsRate >= 30) {
      score += 30;
    } else if (savingsRate >= 20) {
      score += 20;
    } else if (savingsRate >= 10) {
      score += 10;
    } else if (savingsRate < 0) {
      score -= 30;
    }

    // ------------------------------------------
    // EXPENSE TO INCOME RATIO
    // ------------------------------------------

    const expenseRatio =
      (expenses / income) * 100;

    if (expenseRatio <= 50) {
      score += 20;
    } else if (expenseRatio <= 70) {
      score += 10;
    } else if (expenseRatio > 90) {
      score -= 20;
    }

    // Keep score between 0 and 100
    return Math.max(
      0,
      Math.min(
        100,
        Math.round(score)
      )
    );
  };

  const healthScore =
    calculateHealthScore();

  // ==========================================
  // LOAD TRANSACTIONS
  // ==========================================

  const loadTransactions = async () => {
    try {
      const data = await apiRequest(
        `/transactions/${user.id}`
      );

      setTransactions(data);
    } catch (error) {
      alert(error.message);
    }
  };

  // ==========================================
  // LOAD BUDGETS
  // ==========================================

  const loadBudgets = async () => {
    try {
      const data = await apiRequest(
        `/budgets/${user.id}`
      );

      setBudgets(data);
    } catch (error) {
      console.error(error);
    }
  };

  // ==========================================
  // LOAD AI INSIGHTS
  // ==========================================

  const loadAIInsights = async () => {
    try {
      const data = await apiRequest(
        "/ai/insights",
        {
          method: "POST",

          body: JSON.stringify({
            transactions,
          }),
        }
      );

      setAiInsights(
        data.insights || []
      );
    } catch (error) {
      console.error(
        "AI service error:",
        error
      );
    }
  };

  // ==========================================
  // INITIAL DATA LOAD
  // ==========================================

  useEffect(() => {
    loadTransactions();
    loadBudgets();
  }, []);

  // ==========================================
  // ADD / UPDATE TRANSACTION
  // ==========================================

  const handleTransactionSubmit =
    async (form) => {
      try {
        // UPDATE
        if (editingTransaction) {
          const data =
            await apiRequest(
              `/transactions/${editingTransaction._id}`,
              {
                method: "PUT",

                body: JSON.stringify(form),
              }
            );

          setTransactions(
            (previous) =>
              previous.map((item) =>
                item._id ===
                data.transaction._id
                  ? data.transaction
                  : item
              )
          );

          setEditingTransaction(null);

          alert(
            "Transaction updated successfully!"
          );
        }

        // ADD
        else {
          const data =
            await apiRequest(
              "/transactions",
              {
                method: "POST",

                body: JSON.stringify(form),
              }
            );

          setTransactions(
            (previous) => [
              data.transaction,
              ...previous,
            ]
          );

          alert(
            "Transaction added successfully!"
          );
        }
      } catch (error) {
        alert(error.message);
      }
    };

  // ==========================================
  // DELETE TRANSACTION
  // ==========================================

  const handleDelete = async (id) => {
    const confirmDelete =
      window.confirm(
        "Are you sure you want to delete this transaction?"
      );

    if (!confirmDelete) {
      return;
    }

    try {
      await apiRequest(
        `/transactions/${id}`,
        {
          method: "DELETE",
        }
      );

      setTransactions(
        (previous) =>
          previous.filter(
            (item) =>
              item._id !== id
          )
      );

      alert(
        "Transaction deleted!"
      );
    } catch (error) {
      alert(error.message);
    }
  };

  // ==========================================
  // BUDGET CREATED
  // ==========================================

  const handleBudgetCreated =
    (newBudget) => {
      setBudgets(
        (previous) => [
          newBudget,
          ...previous,
        ]
      );
    };

  // ==========================================
  // DELETE BUDGET
  // ==========================================

  const handleBudgetDelete =
    async (id) => {
      const confirmDelete =
        window.confirm(
          "Delete this budget?"
        );

      if (!confirmDelete) {
        return;
      }

      try {
        await apiRequest(
          `/budgets/${id}`,
          {
            method: "DELETE",
          }
        );

        setBudgets(
          (previous) =>
            previous.filter(
              (budget) =>
                budget._id !== id
            )
        );
      } catch (error) {
        alert(error.message);
      }
    };

  // ==========================================
  // CALCULATE SPENT AMOUNT
  // ==========================================

  const getSpentAmount =
    (category) => {
      return transactions
        .filter(
          (item) =>
            item.type === "expense" &&
            item.category === category
        )
        .reduce(
          (sum, item) =>
            sum + Number(item.amount),
          0
        );
    };

  // ==========================================
  // HEALTH SCORE MESSAGE
  // ==========================================

  const getHealthMessage = () => {
    if (transactions.length === 0) {
      return "Add transactions to calculate your financial health.";
    }

    if (healthScore >= 80) {
      return "Excellent! Your financial habits are very healthy.";
    }

    if (healthScore >= 60) {
      return "Good! Your finances are moving in the right direction.";
    }

    if (healthScore >= 40) {
      return "Fair. Consider reducing expenses and increasing savings.";
    }

    return "Needs improvement. Focus on controlling expenses and building savings.";
  };

  // ==========================================
  // DASHBOARD UI
  // ==========================================

  return (
    <>
      <Navbar />

      <main className="container">

        {/* ================================
            DASHBOARD HEADER
        ================================= */}

        <div className="dashboard-header">

          <h1>
            Financial Dashboard
          </h1>

          <p>
            Welcome back, {user?.name}.
            Here's your financial overview.
          </p>

        </div>


        {/* ================================
            SUMMARY CARDS
        ================================= */}

        <SummaryCards
          transactions={transactions}
        />


        {/* ================================
            FINANCIAL HEALTH SCORE
        ================================= */}

        <div
          className="card"
          style={{
            marginTop: "22px",
            textAlign: "center",
          }}
        >

          <h2>
            💚 Financial Health Score
          </h2>

          <div
            style={{
              fontSize: "52px",
              fontWeight: "700",
              margin: "15px 0",
            }}
          >

            {healthScore}

            <span
              style={{
                fontSize: "22px",
                color: "#6b7280",
              }}
            >
              /100
            </span>

          </div>

          <p>
            {getHealthMessage()}
          </p>

        </div>


        {/* ================================
            TRANSACTION + BUDGET
        ================================= */}

        <div className="dashboard-grid">

          {/* TRANSACTION FORM */}

          <TransactionForm
            onSubmit={
              handleTransactionSubmit
            }

            editingTransaction={
              editingTransaction
            }

            onCancelEdit={() =>
              setEditingTransaction(null)
            }
          />


          {/* BUDGET MANAGEMENT */}

          <div className="card">

            <h2>
              💰 Budget Management
            </h2>

            <BudgetForm
              onBudgetCreated={
                handleBudgetCreated
              }
            />

            <hr
              style={{
                margin: "25px 0",
              }}
            />

            <h2>
              Your Budgets
            </h2>

            {budgets.length === 0 ? (

              <p>
                No budgets created yet.
              </p>

            ) : (

              budgets.map(
                (budget) => {

                  const spent =
                    getSpentAmount(
                      budget.category
                    );

                  const percentage =
                    budget.amount > 0
                      ? Math.min(
                          (spent /
                            budget.amount) *
                            100,
                          100
                        )
                      : 0;

                  return (

                    <div
                      key={budget._id}
                      style={{
                        marginBottom:
                          "25px",
                      }}
                    >

                      <div
                        style={{
                          display: "flex",
                          justifyContent:
                            "space-between",
                          alignItems:
                            "center",
                        }}
                      >

                        <strong>
                          {budget.category}
                        </strong>

                        <button
                          className="delete-btn"
                          onClick={() =>
                            handleBudgetDelete(
                              budget._id
                            )
                          }
                        >
                          Delete
                        </button>

                      </div>

                      <p>
                        ₹
                        {spent.toLocaleString()}
                        {" / "}
                        ₹
                        {Number(
                          budget.amount
                        ).toLocaleString()}
                      </p>

                      <small>
                        Month: {budget.month}
                      </small>

                      <div
                        className="budget-progress"
                        style={{
                          marginTop:
                            "8px",
                        }}
                      >

                        <div
                          style={{
                            width:
                              `${percentage}%`,
                          }}
                        />

                      </div>

                      <small>
                        {percentage.toFixed(0)}
                        % used
                      </small>

                    </div>

                  );
                }
              )

            )}

          </div>

        </div>


        {/* ================================
            TRANSACTION HISTORY
        ================================= */}

        <div
          style={{
            marginTop: "20px",
          }}
        >

          <TransactionList
            transactions={
              transactions
            }

            onDelete={
              handleDelete
            }

            onEdit={
              setEditingTransaction
            }
          />

        </div>


        {/* ================================
            CHARTS
        ================================= */}

        <Charts
          transactions={
            transactions
          }
        />


        {/* ================================
            AI FINANCIAL INSIGHTS
        ================================= */}

        <div className="ai-box">

          <h2>
            🤖 AI Financial Insights
          </h2>

          <button
            className="primary-btn"
            style={{
              maxWidth: "250px",
            }}

            onClick={
              loadAIInsights
            }
          >
            Analyze My Finances
          </button>


          {/* AI RESULTS */}

          {aiInsights.length > 0 && (

            <ul
              style={{
                marginTop: "20px",
              }}
            >

              {aiInsights.map(
                (insight, index) => (

                  <li key={index}>
                    {insight}
                  </li>

                )
              )}

            </ul>

          )}

        </div>

      </main>
    </>
  );
}

export default Dashboard;