# AI Finance Controller 💰🤖

AI Finance Controller is a full-stack financial management platform that helps users track income, expenses, budgets, spending patterns, and financial health.

## 🚀 Features

- User registration and login
- JWT-based authentication
- Secure password hashing with bcrypt
- Income and expense tracking
- Transaction search and filtering
- Edit and delete transactions
- Budget management
- Budget usage progress
- Expense category analysis
- Income vs expense visualization
- Monthly savings analysis
- Financial Health Score (0–100)
- AI-powered financial insights
- AI-based next-month spending prediction
- Responsive dashboard

## 🛠️ Technology Stack

### Frontend
- React.js
- React Router
- Recharts
- CSS

### Backend
- Node.js
- Express.js
- MongoDB
- Mongoose
- JWT
- bcryptjs
- REST APIs

### AI Service
- Python
- FastAPI
- Uvicorn
- Rule-based financial intelligence
- Spending prediction based on historical monthly expenses

## 🏗️ Project Architecture

```text
AI-Finance-Controller/
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   └── services/
│   └── package.json
│
├── backend/
│   ├── models/
│   ├── routes/
│   ├── middleware/
│   ├── server.js
│   └── package.json
│
├── ai-service/
│   ├── services/
│   ├── main.py
│   └── requirements.txt
│
└── README.md

React Frontend
      |
      | REST API
      v
Node.js + Express
      |
      +-------> MongoDB
      |
      v
Python FastAPI
      |
      v
Financial Analysis
      |
      v
AI Insights + Spending Prediction